sap.ui.define([
	"sap/ui/core/mvc/Controller",
		"sap/ui/model/FilterOperator",
			"sap/m/Dialog",
			"sap/m/List",
				"sap/m/StandardListItem",
					"sap/m/Button",
						"jquery.sap.global",
						"sap/m/MessageToast"
], function(Controller, FilterOperator, Dialog, List, StandardListItem, Button, jQuery,MessageToast) {
	"use strict";

	return Controller.extend("com.google.ProcessAssetReturns.controller.AssetReturn", {
	
				onInit: function() {
					
								var oModel1 = new sap.ui.model.json.JSONModel(jQuery.sap.getModulePath("com.google.AssetReturn.mockdata", "/products.json"));
			this.getView().setModel(oModel1);
			
			var oODataJSONModelScan =  new sap.ui.model.json.JSONModel();
			var oDataScan ={"scanresults": [
					{"AssetReqNo":"10001","PickupDate":""},
						{"AssetReqNo":"10002","PickupDate":""},
							{"AssetReqNo":"10003","PickupDate":""},
								{"AssetReqNo":"20001","PickupDate":""},
									{"AssetReqNo":"20001","PickupDate":""},
										{"AssetReqNo":"20001","PickupDate":""},
											{"AssetReqNo":"20001","PickupDate":""}
					]};
			oODataJSONModelScan.setData(oDataScan);
			this.getView().setModel(oODataJSONModelScan,"ScanCollection");
			
			
			//		this.onSearch();
			//this.getView().setModel({});
				//this._oResponsivePopover = sap.ui.xmlfragment("com.google.ProcessAssetReturns.view.Dialog", this);
			},
			resizableDialog: null,
			onAfterRendering: function() {
			var oTable = this.getView().byId("idProductsTable");
			var that = this;
		    oTable.addEventDelegate({
		       onAfterRendering: function() {
		          var oHeader = this.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
		          for (var i = 0; i < oHeader.length; i++) {
		          var oID = oHeader[i].id;
		          that.onClick(oID);
		        }
		      }
		   }, oTable);
		},
			onClick: function(oID) {
		     var that = this;
		     $('#' + oID).click(function(oEvent) { //Attach Table Header Element Event
			     var oTarget = oEvent.currentTarget; //Get hold of Header Element
			     var oLabelText = oTarget.childNodes[0].textContent; //Get Column Header text
			     var oIndex = oTarget.id.slice(-1); //Get the column Index
			     var oView = that.getView();
			     var oTable = oView.byId("idProductsTable");
			     var oModel = oTable.getModel("OrderCollection").getProperty("/results"); //Get Hold of Table Model Values
			     var oKeys = Object.keys(oModel[0]); //Get Hold of Model Keys to filter the value
			     oView.getModel("OrderCollection").setProperty("/bindingValue", oKeys[oIndex]); //Save the key value to property
			     that._oResponsivePopover.openBy(oTarget);
		     });
		},
		onAscending : function(oEvent){
			var oPath = this.getView().getModel("OrderCollection").getProperty("/bindingValue");
			var oSorter = new sap.ui.model.Sorter(oPath, true);
			var oView = this.getView();
			var oTable = oView.byId("idProductsTable");
			oTable.getBinding("items").sort(oSorter);
			this._oResponsivePopover.close();
		},
		
		onDescending: function(oEvent){
			var oPath = this.getView().getModel("OrderCollection").getProperty("/bindingValue");
			var oSorter = new sap.ui.model.Sorter(oPath);
			var oView = this.getView();
			var oTable = oView.byId("idProductsTable");
			oTable.getBinding("items").sort(oSorter);
			this._oResponsivePopover.close();
		},
		
		onChange : function(oEvent){
			var oPath = this.getView().getModel("OrderCollection").getProperty("/bindingValue");
			var oQuery = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter(oPath, FilterOperator.Contains, oQuery);
			var oView = this.getView();
			var oTable = oView.byId("idProductsTable");
			oTable.getBinding("items").filter(oFilter);
			this._oResponsivePopover.close();
		},
			onSearch:function(){
					this.byId("idUnmatchedTable").setVisible(false);
					this.byId("idProductsTable").setVisible(true);
					this.byId("idProductsTable1").setVisible(false);
			var oODataJSONModel =  new sap.ui.model.json.JSONModel();
			var oData ={"results": [
					{"MaintenanceOrderNumber":"1000000020","OperationNumber":"10","AssetReqNo":"10001","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","PickupLocation":"TC6","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000020","OperationNumber":"20","AssetReqNo":"10002","MaterialNumber":"910000022","MaterialDesc":"Dell","PickupLocation":"TC6","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000020","OperationNumber":"30","AssetReqNo":"10003","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","PickupLocation":"TC5","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000021","OperationNumber":"10","AssetReqNo":"10004","MaterialNumber":"910000024","MaterialDesc":"Head phone","PickupLocation":"TC5","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000021","OperationNumber":"20","AssetReqNo":"10005","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC4","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000022","OperationNumber":"10","AssetReqNo":"10006","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC4","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000023","OperationNumber":"10","AssetReqNo":"10007","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","PickupLocation":"TC3","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000023","OperationNumber":"20","AssetReqNo":"10008","MaterialNumber":"910000022","MaterialDesc":"Dell","PickupLocation":"TC2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000024","OperationNumber":"10","AssetReqNo":"10009","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","PickupLocation":"TC1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000025","OperationNumber":"10","AssetReqNo":"10010","MaterialNumber":"910000024","MaterialDesc":"Head phone","PickupLocation":"TC6","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000025","OperationNumber":"20","AssetReqNo":"10011","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000026","OperationNumber":"10","AssetReqNo":"10012","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000026","OperationNumber":"20","AssetReqNo":"10013","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","PickupLocation":"TC3","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000027","OperationNumber":"10","AssetReqNo":"10014","MaterialNumber":"910000022","MaterialDesc":"Dell","PickupLocation":"TC4","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000027","OperationNumber":"20","AssetReqNo":"10015","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","PickupLocation":"TC5","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000028","OperationNumber":"10","AssetReqNo":"10016","MaterialNumber":"910000024","MaterialDesc":"Head phone","PickupLocation":"TC6","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000028","OperationNumber":"20","AssetReqNo":"10017","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC6","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000029","OperationNumber":"10","AssetReqNo":"10018","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC6","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000030","OperationNumber":"10","AssetReqNo":"10019","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","PickupLocation":"TC1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000030","OperationNumber":"20","AssetReqNo":"10020","MaterialNumber":"910000022","MaterialDesc":"Dell","PickupLocation":"TC5","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000030","OperationNumber":"30","AssetReqNo":"10021","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","PickupLocation":"TC4","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000031","OperationNumber":"10","AssetReqNo":"10022","MaterialNumber":"910000024","MaterialDesc":"Head phone","PickupLocation":"TC3","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000031","OperationNumber":"20","AssetReqNo":"10023","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""},
					{"MaintenanceOrderNumber":"1000000031","OperationNumber":"30","AssetReqNo":"10024","MaterialNumber":"910000025","MaterialDesc":"Monitor","PickupLocation":"TC1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Return Initiated", "PickupDate":""}
					]};
			oODataJSONModel.setData(oData);
			this.getView().setModel(oODataJSONModel,"OrderCollection");
		},
		handleValueHelp : function (oController) {
			var oODataJSONModel =  new sap.ui.model.json.JSONModel();
			var oData ={"results": [
				{"PlantName":"Plant A","PlantId":"I027"},
				{"PlantName":"Plant B","PlantId":"I028"}
				]};
			oODataJSONModel.setData(oData);
			this.getView().setModel(oODataJSONModel,"PlantCollection");
			// this.inputId = oController.oSource.sId;
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"com.ordopOrders_Operations.view.Dialog",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// open value help dialog
			this._valueHelpDialog.open();
		},

		_handleValueHelpSearch : function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new sap.m.Filter(
				"Name",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClose : function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId("inpPlant");
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		},
		onResizableDialog:function(){
			

			
						if (!this.resizableDialog) {
				this.resizableDialog = new Dialog({
					title: "Scan the Assets for Matching",
					contentWidth: "550px",
					contentHeight: "300px",
					resizable: true,
					content: new List({
						items: {
							path: "/scanresults",
							template: new StandardListItem({
								title: "{AssetReqNo}"
							
							
							})
						}
					}),
					beginButton: new Button({
						text: "Confirm Scan",
						press: function () {
							this.resizableDialog.close();
							this.byId("idProductsTable").setVisible(false);
							this.byId("idProductsTable1").setVisible(true);
							this.byId("idUnmatchedTable").setVisible(true);
							
							
						
							var oModel = 	this.byId("idProductsTable").getModel("OrderCollection");
							oModel.getData().results[0].OperationStatus="Picked";
							oModel.getData().results[1].OperationStatus="Picked";
							oModel.getData().results[2].OperationStatus="Picked";
							
														oModel.getData().results[0].PickupDate=new Date();
							oModel.getData().results[1].PickupDate=new Date();
							oModel.getData().results[2].PickupDate=new Date();
							
							oModel.refresh();
							//this.byId("idProductsTable1").setModel(oModel, "OrderCollection");
						}.bind(this)
					})
				
				});

				//to get access to the global model
			//	this.getView().addDependent(this.resizableDialog);
			}
			var oODataJSONModelScan =  new sap.ui.model.json.JSONModel();
			var oDataScan ={"scanresults": [
					{"AssetReqNo":"10001","PickupDate":""},
						{"AssetReqNo":"10002","PickupDate":""},
							{"AssetReqNo":"10003","PickupDate":""},
								{"AssetReqNo":"20001","PickupDate":""},
									{"AssetReqNo":"20002","PickupDate":""}
					]};
			oODataJSONModelScan.setData(oDataScan);
			this.resizableDialog.setModel(oODataJSONModelScan);
			this.unmatchedRecords();
		//	var oModel1 = new sap.ui.model.json.JSONModel(jQuery.sap.getModulePath("com.google.AssetReturn.mockdata", "/products.json"));
		//	this.resizableDialog.setModel(oModel1);
			this.resizableDialog.open();
		},
		unmatchedRecords:function(){
						var oODataJSONModelScanUnmatched =  new sap.ui.model.json.JSONModel();
			var oDataScanunmatched ={"scanumatchedresults": [
				
								{"AssetReqNo":"20001","PickupDate":""},
									{"AssetReqNo":"20002","PickupDate":""}
					]};
			oODataJSONModelScanUnmatched.setData(oDataScanunmatched);
		this.byId("idUnmatchedTable").setModel(oODataJSONModelScanUnmatched, "UnmatchedCollection");
		},
		onTable2Press:function(){
			MessageToast.show("Asset Return Request Submitted Sucessfully");
		},
		onCreateReturnOrder:function(){
			MessageToast.show("Create Asset Return Request Maintenance Order created Sucessfully");
		}
	});
});