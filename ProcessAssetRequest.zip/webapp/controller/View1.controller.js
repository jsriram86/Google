sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.ordopOrders_Operations.controller.View1", {
	onInit: function() {	
		var oModel, oView;
		jQuery.sap.require("sap.ui.core.util.MockServer");
		var oMockServer = new sap.ui.core.util.MockServer({
			rootUri: "foo/"
		});
		this._oMockServer = oMockServer;
		oMockServer.simulate("mockserver/metadata.xml", "mockserver/");
		oMockServer.start();
		oModel = new sap.ui.model.odata.ODataModel("foo", true);
		oModel.setCountSupported(false);
		oView = this.getView();
		oView.setModel(oModel);
	
			
		},
		onExit: function() {
		this._oMockServer.stop();
	},
		onSearch:function(){
			var oODataJSONModel =  new sap.ui.model.json.JSONModel();
			var oData ={"results": [
					{"OrderNumber":"1000000020","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","Quantity":"1","AssignedSNo":"","ProposedSNo":"9000001","OperationStatus":"In progress"},
					{"OrderNumber":"1000000021","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000022","MaterialDesc":"Dell","Quantity":"3","AssignedSNo":"","ProposedSNo":"9000002","OperationStatus":"Imaging in progress"},
					{"OrderNumber":"1000000022","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","Quantity":"2","AssignedSNo":"","ProposedSNo":"9000003","OperationStatus":"Picked"},
					{"OrderNumber":"1000000023","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000024","MaterialDesc":"Head phone","Quantity":"1","AssignedSNo":"","ProposedSNo":"9000004","OperationStatus":"Ready for Shipment"},
					{"OrderNumber":"1000000024","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"2","AssignedSNo":"","ProposedSNo":"9000005","OperationStatus":"In Progress"},
					{"OrderNumber":"1000000025","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"1","AssignedSNo":"","ProposedSNo":"9000006","OperationStatus":"Delivered"},
					
					]};
			oODataJSONModel.setData(oData);
			this.getView().setModel(oODataJSONModel,"OrderCollection");
		}

	});
});