sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/FilterOperator"
], function(Controller, FilterOperator) {
	"use strict";

	return Controller.extend("com.google.ProcessDelivery.controller.View1", {
		init:function(){
			
		},
		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.saudiaramco.fiori.qm.notifications.view.DisplayNotification
		 */
			onInit: function() {
				this.getView().setModel({});
				this._oResponsivePopover = sap.ui.xmlfragment("com.google.ProcessDelivery.view.Dialog", this);
			},
		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.saudiaramco.fiori.qm.notifications.view.DisplayNotification
		 */
		onAfterRendering: function() {
			var oTable = this.getView().byId("idOrderTable");
			var that = this;
		    oTable.addEventDelegate({
		       onAfterRendering: function() {
		          var oHeader = this.$().find('.sapMListTblHeaderCell'); //Get hold of table header elements
		          for (var i = 0; i < oHeader.length; i++) {
		          var oID = oHeader[i].id;
		          that.onClick(oID);
		        }
		      }
		   }, oTable);
		},
		
		onClick: function(oID) {
		     var that = this;
		     $('#' + oID).click(function(oEvent) { //Attach Table Header Element Event
			     var oTarget = oEvent.currentTarget; //Get hold of Header Element
			     var oLabelText = oTarget.childNodes[0].textContent; //Get Column Header text
			     var oIndex = oTarget.id.slice(-1); //Get the column Index
			     var oView = that.getView();
			     var oTable = oView.byId("idOrderTable");
			     var oModel = oTable.getModel("OrderCollection").getProperty("/results"); //Get Hold of Table Model Values
			     var oKeys = Object.keys(oModel[0]); //Get Hold of Model Keys to filter the value
			     oView.getModel("OrderCollection").setProperty("/bindingValue", oKeys[oIndex]); //Save the key value to property
			     that._oResponsivePopover.openBy(oTarget);
		     });
		},
		onAscending : function(oEvent){
			var oPath = this.getView().getModel("OrderCollection").getProperty("/bindingValue");
			var oSorter = new sap.ui.model.Sorter(oPath, true);
			var oView = this.getView();
			var oTable = oView.byId("idOrderTable");
			oTable.getBinding("items").sort(oSorter);
			this._oResponsivePopover.close();
		},
		
		onDescending: function(oEvent){
			var oPath = this.getView().getModel("OrderCollection").getProperty("/bindingValue");
			var oSorter = new sap.ui.model.Sorter(oPath);
			var oView = this.getView();
			var oTable = oView.byId("idOrderTable");
			oTable.getBinding("items").sort(oSorter);
			this._oResponsivePopover.close();
		},
		
		onChange : function(oEvent){
			var oPath = this.getView().getModel("OrderCollection").getProperty("/bindingValue");
			var oQuery = oEvent.getParameter("value");
			var oFilter = new sap.ui.model.Filter(oPath, FilterOperator.Contains, oQuery);
			var oView = this.getView();
			var oTable = oView.byId("idOrderTable");
			oTable.getBinding("items").filter(oFilter);
			this._oResponsivePopover.close();
		},
		
		onSearch:function(){
			var oODataJSONModel =  new sap.ui.model.json.JSONModel();
			var oData ={"results": [
					{"OrderNumber":"1000000020","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"In progress", "DelDateTime":""},
					{"OrderNumber":"1000000021","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000022","MaterialDesc":"Dell","Quantity":"3","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Imaging in progress", "DelDateTime":""},
					{"OrderNumber":"1000000022","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Picked", "DelDateTime":""},
					{"OrderNumber":"1000000023","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000024","MaterialDesc":"Head phone","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Ready for Shipment", "DelDateTime":""},
					{"OrderNumber":"1000000024","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Out for Delivery", "DelDateTime":""},
					{"OrderNumber":"1000000025","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Delivered", "DelDateTime":""},
					{"OrderNumber":"1000000026","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"In progress", "DelDateTime":""},
					{"OrderNumber":"1000000027","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000022","MaterialDesc":"Dell","Quantity":"3","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Imaging in progress", "DelDateTime":""},
					{"OrderNumber":"1000000028","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Picked", "DelDateTime":""},
					{"OrderNumber":"1000000029","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000024","MaterialDesc":"Head phone","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Ready for Shipment", "DelDateTime":""},
					{"OrderNumber":"1000000030","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Out for Delivery", "DelDateTime":""},
					{"OrderNumber":"1000000031","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Delivered", "DelDateTime":""},
					{"OrderNumber":"1000000032","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"In progress", "DelDateTime":""},
					{"OrderNumber":"1000000033","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000022","MaterialDesc":"Dell","Quantity":"3","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Imaging in progress", "DelDateTime":""},
					{"OrderNumber":"1000000034","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Picked", "DelDateTime":""},
					{"OrderNumber":"1000000035","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000024","MaterialDesc":"Head phone","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Ready for Shipment", "DelDateTime":""},
					{"OrderNumber":"1000000036","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Out for Delivery", "DelDateTime":""},
					{"OrderNumber":"1000000037","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Delivered", "DelDateTime":""},
					{"OrderNumber":"1000000038","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000021","MaterialDesc":"Macbook pro","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"In progress", "DelDateTime":""},
					{"OrderNumber":"1000000039","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000022","MaterialDesc":"Dell","Quantity":"3","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Imaging in progress", "DelDateTime":""},
					{"OrderNumber":"1000000040","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000023","MaterialDesc":"Pixel Phone","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Picked", "DelDateTime":""},
					{"OrderNumber":"1000000041","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000024","MaterialDesc":"Head phone","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Ready for Shipment", "DelDateTime":""},
					{"OrderNumber":"1000000042","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"2","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Out for Delivery", "DelDateTime":""},
					{"OrderNumber":"1000000043","OperationNumber":"10","OperationDesc":"Asset Request","MaterialNumber":"910000025","MaterialDesc":"Monitor","Quantity":"1","TrackingNumber":"","InventoryTechComments":"","OperationStatus":"Delivered", "DelDateTime":""}
					]};
			oODataJSONModel.setData(oData);
			this.getView().setModel(oODataJSONModel,"OrderCollection");
		},
		handleValueHelp : function (oController) {
			var oODataJSONModel =  new sap.ui.model.json.JSONModel();
			var oData ={"results": [
				{"PlantName":"Plant A","PlantId":"I027"},
				{"PlantName":"Plant B","PlantId":"I028"}
				]};
			oODataJSONModel.setData(oData);
			this.getView().setModel(oODataJSONModel,"PlantCollection");
			// this.inputId = oController.oSource.sId;
			// create value help dialog
			if (!this._valueHelpDialog) {
				this._valueHelpDialog = sap.ui.xmlfragment(
					"com.ordopOrders_Operations.view.Dialog",
					this
				);
				this.getView().addDependent(this._valueHelpDialog);
			}

			// open value help dialog
			this._valueHelpDialog.open();
		},

		_handleValueHelpSearch : function (evt) {
			var sValue = evt.getParameter("value");
			var oFilter = new sap.m.Filter(
				"Name",
				sap.ui.model.FilterOperator.Contains, sValue
			);
			evt.getSource().getBinding("items").filter([oFilter]);
		},

		_handleValueHelpClose : function (evt) {
			var oSelectedItem = evt.getParameter("selectedItem");
			if (oSelectedItem) {
				var productInput = this.byId("inpPlant");
				productInput.setValue(oSelectedItem.getTitle());
			}
			evt.getSource().getBinding("items").filter([]);
		}

	});
});